package com.example.l1z2java;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;
import java.util.Random;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String pass = "";
    private final ArrayList<String> withSpaces = new ArrayList<>();
    private final ArrayList<String> letters = new ArrayList<>();
    private final Random random = new Random();
    private final String[] words = {"median", "axis", "matrix", "digit", "bias", "equal", "finite", "gross", "half", "inch", "joule", "knot", "limit", "number", "octal", "plot", "quart", "ratio", "scale", "torus", "unit", "vector", "width", "zero"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start();
    }

    private void start() {
        withSpaces.clear();
        letters.clear();
        String word = generateWord();
        String reverse;
        for (int i = word.length() - 1; i >= 0; i--) {
            letters.add(String.valueOf(word.charAt(i)));
        }
        StringBuilder password = new StringBuilder();
        StringBuilder temp = new StringBuilder();
        for (int i = 1; i < word.length(); i++) {
            temp.append(letters.get(i - 1)).append(" ");
            password.append("_ ");
        }
        temp.append(letters.get(word.length() - 1));
        password.append("_");
        reverse = temp.toString();
        for (int i = reverse.length() - 1; i >= 0; i--) {
            withSpaces.add(String.valueOf(reverse.charAt(i)));
        }
        pass = password.toString();
        TextView passw = findViewById(R.id.passw);
        passw.setText(pass);
    }

    private void update(String guess) {
        if (guess.length() > 1) {
            Toast.makeText(this, "Enter only one letter!", Toast.LENGTH_SHORT).show();
        }
        if (guess.isEmpty()) {
            Toast.makeText(this, "Enter a letter!:)", Toast.LENGTH_SHORT).show();
        }
        else {
            ArrayList<Integer> indices = new ArrayList<>();
            if (letters.contains(guess)) {
                for (int i = 0; i < withSpaces.size(); i++) {
                    if (withSpaces.get(i).equalsIgnoreCase(guess)) {
                        indices.add(i);
                    }
                }
                indices.forEach((i) -> pass = pass.substring(0, i) + withSpaces.get(i) + pass.substring(i + 1));
                TextView passw = findViewById(R.id.passw);
                passw.setText(pass);
                while (letters.contains(guess)) {
                    letters.remove(guess);
                }
            }
        }
        if (letters.isEmpty()) {
            Toast.makeText(this, "You've won!!!", Toast.LENGTH_LONG).show();
            start();
        }
    }

    private String generateWord() {
        return words[random.nextInt(words.length - 1)];
    }

    public void checkClick(View view) {
        EditText edit = findViewById(R.id.input);
        String guess = String.valueOf(edit.getText());
        update(guess);
    }

    public void clueClick(View view) {
        int randomize = random.nextInt(letters.size());
        String randomGuess = letters.get(randomize);
        update(randomGuess);
    }
}