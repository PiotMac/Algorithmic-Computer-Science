package com.example.l2z1minesweeper

import android.app.ActionBar.LayoutParams
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.w3c.dom.Text
import java.security.SecureRandom


class MainActivity : AppCompatActivity() {

    private val columns = 9
    private val rows = 9
    private val numberOfBombs = 10
    private var goodFlagCount = 0
    private var flagsSet = 0

    private val toRevealTiles = hashSetOf<Square?>()
    private val tiles = Array(rows) { arrayOfNulls<ImageButton>(columns)}
    private val squares = Array(rows) { arrayOfNulls<Square>(columns) }
    private val numbers = intArrayOf(R.drawable.one, R.drawable.two, R.drawable.three, R.drawable.four, R.drawable.five, R.drawable.six, R.drawable.seven, R.drawable.eight)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createUI()
    }

    private fun createUI() {
        val grid = findViewById<GridLayout>(R.id.grid)
        grid.removeAllViews()
        toRevealTiles.clear()
        goodFlagCount = 0
        flagsSet = numberOfBombs
        findViewById<TextView>(R.id.flagsOnBoard).text = flagsSet.toString()

        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height = displayMetrics.heightPixels
        val width = displayMetrics.widthPixels

        grid.columnCount = columns
        grid.rowCount = rows

        for (i in 0 until rows) {
            for (j in 0 until columns) {
                val first = "" + i
                val second = "" + j
                tiles[i][j] = ImageButton(this)
                tiles[i][j]?.setImageDrawable(resources.getDrawable(R.drawable.untouched, applicationContext.theme))
                tiles[i][j]?.id = Integer.parseInt(first + second)
                tiles[i][j]?.setOnClickListener(onClick)
                tiles[i][j]?.setOnLongClickListener(onLongClick)
                tiles[i][j]?.adjustViewBounds = true
                tiles[i][j]?.maxWidth = width / columns
                tiles[i][j]?.maxHeight = height / rows
                tiles[i][j]?.layoutParams?.height = LayoutParams.WRAP_CONTENT
                tiles[i][j]?.layoutParams?.width = LayoutParams.WRAP_CONTENT
                tiles[i][j]?.setPadding(0,0,0,0)
                grid.addView(tiles[i][j])
            }
        }
        setLogic()
    }

    private fun setLogic() {
        //Setting squares
        for (i in 0 until rows) {
            for( j in 0 until columns) {
                squares[i][j] = Square(i, j)
            }
        }

        //Setting neighbours
        val neighbours = arrayListOf<Square>()
        for (i in 0 until rows) {
            for (j in 0 until columns) {
                if (i != 0 && i != rows - 1 && j != 0 && j != columns - 1) {
                    //Top neighbours
                    squares[i - 1][j - 1]?.let { neighbours.add(it) }
                    squares[i][j - 1]?.let { neighbours.add(it) }
                    squares[i + 1][j - 1]?.let { neighbours.add(it) }
                    //Middle neighbours
                    squares[i - 1][j]?.let { neighbours.add(it) }
                    squares[i + 1][j]?.let { neighbours.add(it) }
                    //Bottom neighbours
                    squares[i - 1][j + 1]?.let { neighbours.add(it) }
                    squares[i][j + 1]?.let { neighbours.add(it) }
                    squares[i + 1][j + 1]?.let { neighbours.add(it) }
                }
                else if (i == 0) {
                    if (j == 0) {
                        squares[i + 1][j]?.let { neighbours.add(it) }
                        squares[i][j + 1]?.let { neighbours.add(it) }
                        squares[i + 1][j + 1]?.let { neighbours.add(it) }
                    }
                    else if (j == columns - 1) {
                        squares[i][j - 1]?.let { neighbours.add(it) }
                        squares[i + 1][j - 1]?.let { neighbours.add(it) }
                        squares[i + 1][j]?.let { neighbours.add(it) }
                    }
                    else {
                        squares[i][j - 1]?.let { neighbours.add(it) }
                        squares[i + 1][j - 1]?.let { neighbours.add(it) }
                        squares[i + 1][j]?.let { neighbours.add(it) }
                        squares[i][j + 1]?.let { neighbours.add(it) }
                        squares[i + 1][j + 1]?.let { neighbours.add(it) }
                    }
                }
                else if (i == rows - 1) {
                    if (j == 0) {
                        squares[i - 1][j]?.let { neighbours.add(it) }
                        squares[i - 1][j + 1]?.let { neighbours.add(it) }
                        squares[i][j + 1]?.let { neighbours.add(it) }
                    }
                    else if (j == columns - 1) {
                        squares[i - 1][j]?.let { neighbours.add(it) }
                        squares[i - 1][j - 1]?.let { neighbours.add(it) }
                        squares[i][j - 1]?.let { neighbours.add(it) }
                    }
                    else {
                        squares[i - 1][j - 1]?.let { neighbours.add(it) }
                        squares[i][j - 1]?.let { neighbours.add(it) }
                        squares[i - 1][j]?.let { neighbours.add(it) }
                        squares[i - 1][j + 1]?.let { neighbours.add(it) }
                        squares[i][j + 1]?.let { neighbours.add(it) }
                    }
                }
                else if (j == 0) {
                    squares[i - 1][j]?.let { neighbours.add(it) }
                    squares[i + 1][j]?.let { neighbours.add(it) }
                    squares[i - 1][j + 1]?.let { neighbours.add(it) }
                    squares[i][j + 1]?.let { neighbours.add(it) }
                    squares[i + 1][j + 1]?.let { neighbours.add(it) }
                }
                else if (j == columns - 1) {
                    squares[i - 1][j - 1]?.let { neighbours.add(it) }
                    squares[i][j - 1]?.let { neighbours.add(it) }
                    squares[i + 1][j - 1]?.let { neighbours.add(it) }
                    squares[i - 1][j]?.let { neighbours.add(it) }
                    squares[i + 1][j]?.let { neighbours.add(it) }
                }
                squares[i][j]?.setNeighbours(neighbours)
                neighbours.clear()
            }
        }

        //Setting bombs
        var bombsCounter = 0
        val random = SecureRandom()
        while (bombsCounter != numberOfBombs) {
            val guessColumns = random.nextInt(columns)
            val guessRows = random.nextInt(rows)
            if (!squares[guessRows][guessColumns]?.isBombSet()!!) {
                squares[guessRows][guessColumns]?.setBomb()
                bombsCounter++
            }
        }

        //Setting numbers on the tiles and creating hash set of tiles to reveal
        for (i in 0 until rows) {
            for (j in 0 until columns) {
                if (squares[i][j]?.isBombSet() == false) {
                    toRevealTiles.add(squares[i][j])
                }
                squares[i][j]?.setNearbyBombs()
            }
        }
    }

    //Method on smiley click
    fun smileyClick(view: View) {
        createUI()
    }

    //Method on short click
    private val onClick = View.OnClickListener {
        val id = it.id
        val row: Int
        val column: Int
        if (id < 10) {
            row = 0
            column = id
        }
        else {
            row = id / 10
            column = id % 10
        }
        if (squares[row][column]?.isBombSet() == true) {
            findViewById<ImageButton>(id).setImageDrawable(resources.getDrawable(R.drawable.bomb, applicationContext.theme))
            Toast.makeText(this, "You've lost!", Toast.LENGTH_SHORT).show()
            squares[row][column]?.setTouched()
            createUI()
        }
        else {
            val bombs = squares[row][column]?.getNearbyBombs()
            if (bombs == 0) {
                clearAll(squares[row][column], id)
            }
            else {
                if (bombs != null) {
                    revealTile(squares[row][column],id)
                }
            }
        }
    }

    //Method on long click
    private val onLongClick = View.OnLongClickListener {
        val id = it.id
        val row: Int
        val column: Int
        if (id < 10) {
            row = 0
            column = id
        }
        else {
            row = id / 10
            column = id % 10
        }
        if (squares[row][column]?.isUntouched() == false) {
            return@OnLongClickListener true
        }
        else if (squares[row][column]?.isFlagSet() == true) {
            findViewById<ImageButton>(id).setImageDrawable(resources.getDrawable(R.drawable.untouched, applicationContext.theme))
            squares[row][column]?.resetFlag()
            flagsSet++
            if (squares[row][column]?.isBombSet() == true) {
                goodFlagCount--
            }
        }
        else {
            findViewById<ImageButton>(id).setImageDrawable(resources.getDrawable(R.drawable.flag, applicationContext.theme))
            squares[row][column]?.setFlag()
            flagsSet--
            if (squares[row][column]?.isBombSet() == true) {
                goodFlagCount++
            }
            if (goodFlagCount == numberOfBombs && toRevealTiles.isEmpty()) {
                Toast.makeText(this, "You've won!", Toast.LENGTH_SHORT).show()
                createUI()
            }
        }
        findViewById<TextView>(R.id.flagsOnBoard).text = flagsSet.toString()
        true
    }

    private fun clearAll(square: Square?, id : Int) {
        if (square == null) {
            return
        }
        if (square.isUntouched()) {
            revealTile(square, id)
        }
        if (square.getNearbyBombs() == 0) {
            val neighbours = square.getNeighbours()
            val untouched = arrayListOf<Square>()
            for (i in 0 until neighbours.size) {
                if (neighbours[i].isUntouched()) {
                    untouched.add(neighbours[i])
                }
            }
            for (i in 0 until untouched.size) {
                val x = "" + untouched[i].getX()
                val y = "" + untouched[i].getY()
                val coords = Integer.parseInt(x + y)
                if (untouched[i].getNearbyBombs() > 0) {
                    revealTile(untouched[i], coords)
                }
                else if (untouched[i].isBombSet()) {
                    continue
                }
                else {
                    clearAll(untouched[i], coords)
                }
            }
        }
    }

    private fun revealTile(square: Square?, id: Int) {
        if (square == null) {
            return
        }
        square.setTouched()
        val bombs = square.getNearbyBombs()
        if (bombs == 0){
            if (!square.isBombSet()) {
                findViewById<ImageButton>(id).setImageDrawable(resources.getDrawable(R.drawable.empty, applicationContext.theme))
            }
            else {
                findViewById<ImageButton>(id).setImageDrawable(resources.getDrawable(R.drawable.bomb, applicationContext.theme))
            }
        }
        else {
            findViewById<ImageButton>(id).setImageDrawable(resources.getDrawable(numbers[bombs - 1], applicationContext.theme))
        }
        if (toRevealTiles.contains(square)) {
            toRevealTiles.remove(square)
        }
        if (goodFlagCount == numberOfBombs && toRevealTiles.isEmpty()) {
            Toast.makeText(this, "You've won!", Toast.LENGTH_SHORT).show()
            createUI()
        }
    }
}