package com.example.l2z1minesweeper

class Square(private val x: Int, private val y: Int) {
    private var unTouched = true
    private var flagSet = false
    private var bombSet = false
    private var nearbyBombs = 0
    private var neighbours = arrayListOf<Square>()

    fun getX() : Int {
        return x
    }

    fun getY() : Int {
        return y
    }

    fun setNeighbours(neighbours : ArrayList<Square>) {
        for (i in 0 until neighbours.size) {
            this.neighbours.add(neighbours[i])
        }
    }

    fun getNeighbours(): ArrayList<Square> {
        return neighbours
    }


    fun setNearbyBombs() {
        for (i in 0 until neighbours.size) {
            if (neighbours[i].isBombSet()) {
                nearbyBombs++
            }
        }
    }

    fun getNearbyBombs(): Int {
        return nearbyBombs
    }

    fun isUntouched() : Boolean {
        return unTouched
    }

    fun setTouched() {
        unTouched = false
    }

    fun isFlagSet(): Boolean {
        return flagSet
    }

    fun isBombSet(): Boolean {
        return bombSet
    }

    fun setFlag() {
        flagSet = true;
    }

    fun resetFlag() {
        flagSet = false;
    }

    fun setBomb() {
        bombSet = true;
    }

    fun resetBomb() {
        bombSet = false;
    }
}