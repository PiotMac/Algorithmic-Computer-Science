package com.example.l2z2wisielec

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlin.collections.ArrayList
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private var word = ""
    private var pass = ""
    private var reverse = ""
    private var withSpaces = arrayListOf<String>()
    private var letters = arrayListOf<String>()
    private var mistakes = 0
    private val images = intArrayOf(R.drawable.wisielec0, R.drawable.wisielec1, R.drawable.wisielec2, R.drawable.wisielec3, R.drawable.wisielec4,
                                    R.drawable.wisielec5, R.drawable.wisielec6, R.drawable.wisielec7, R.drawable.wisielec8,
                                    R.drawable.wisielec9, R.drawable.wisielec10, R.drawable.wisielec11, R.drawable.wisielec12)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        start()
    }

    private fun start() {
        findViewById<ImageView>(R.id.wisielec).setImageDrawable(resources.getDrawable(R.drawable.wisielec0, applicationContext.theme))
        word = generateWord()
        reverse = word
        letters = reverse.chunked(1) as ArrayList<String>
        val password = StringBuilder()
        val temp = StringBuilder()
        for (i in 1 until word.length step 1) {
            temp.append(letters[i - 1] + " ")
            password.append("_ ")
        }
        temp.append(letters[word.length - 1])
        password.append("_")
        reverse = temp.toString()
        withSpaces = reverse.chunked(1) as ArrayList<String>
        pass = password.toString()
        findViewById<TextView>(R.id.passw).text = pass
    }

    private fun update(guess: String) {
        findViewById<EditText>(R.id.input).setText("")
        if (guess.length > 1) {
            Toast.makeText(this, "Enter only one letter!", Toast.LENGTH_SHORT).show()
        }
        else if (guess.isEmpty()) {
            Toast.makeText(this, "Enter a letter!:)", Toast.LENGTH_SHORT).show()
        }
        else {
            val indices = arrayListOf<Int>()
            if (letters.contains(guess)) {
                for (i in 0 until withSpaces.size step 1) {
                    if (withSpaces[i] == guess) {
                        indices.add(i)
                    }
                }
                for (i in indices) {
                    pass = pass.substring(0, i) + withSpaces[i] + pass.substring(i + 1)
                }
                findViewById<TextView>(R.id.passw).text = pass
                while (letters.contains(guess)) {
                    letters.remove(guess)
                }
                Toast.makeText(this, "You've guessed a letter!", Toast.LENGTH_SHORT).show()
            }
            else {
                Toast.makeText(this, "Wrong!", Toast.LENGTH_SHORT).show()
                mistakes++
                if (mistakes == 12) {
                    Toast.makeText(this, "You've lost!:(", Toast.LENGTH_LONG).show()
                    mistakes = 0
                    start()
                }
                findViewById<ImageView>(R.id.wisielec).setImageDrawable(resources.getDrawable(images[mistakes], applicationContext.theme))
            }
        }
        if (letters.isEmpty()) {
            Toast.makeText(this, "You've won!!!", Toast.LENGTH_LONG).show()
            mistakes = 0
            start()
        }
    }

    private fun generateWord(): String {
        val size = resources.getStringArray(R.array.dictionary).size
        val sample = Random.nextInt(0, size)
        return resources.getStringArray(R.array.dictionary)[sample]
    }

    fun checkClick(view: View) {
        val guess = findViewById<EditText>(R.id.input).text.toString()
        update(guess)
    }

    fun clueClick(view: View) {
        val random = Random.nextInt(0, letters.size)
        val randomGuess = letters[random]
        update(randomGuess)
    }
}