package com.example.calendarapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import java.time.LocalDate


class CalendarAdapter(private val days: ArrayList<LocalDate?>, private val onItemListener: OnItemListener) : RecyclerView.Adapter<CalendarViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CalendarViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view: View = inflater.inflate(R.layout.calendar_cell, parent, false)
        val layoutParams = view.layoutParams
        if (days.size > 15)
            layoutParams.height = (parent.height * 0.166666666).toInt() else
            layoutParams.height = parent.height
        return CalendarViewHolder(view, onItemListener, days)
    }

    override fun onBindViewHolder(holder: CalendarViewHolder, position: Int) {
        val date = days[position]
        if (date == null) holder.dayOfMonth.text = "" else {
            holder.dayOfMonth.text = date.dayOfMonth.toString()
            if (position % 7 == 6) {
                holder.dayOfMonth.setTextColor(ContextCompat.getColor(holder.parentView.context, R.color.light_red))
            }

            if (date == Formatting.selectedDate) {
                holder.parentView.setBackgroundColor(ContextCompat.getColor(holder.parentView.context, R.color.gray));
            }

            if (date == Formatting.originalDate) {
                holder.parentView.setBackgroundColor(ContextCompat.getColor(holder.parentView.context, R.color.dark_red))
            }
        }
    }

    override fun getItemCount(): Int {
        return days.size
    }

    interface OnItemListener {
        fun onItemClick(position: Int, date: LocalDate?)
    }
}