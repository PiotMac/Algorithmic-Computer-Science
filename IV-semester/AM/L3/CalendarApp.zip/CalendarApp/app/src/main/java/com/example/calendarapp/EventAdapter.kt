package com.example.calendarapp

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import androidx.core.view.size


class EventAdapter(context: Context, events: List<Event?>?) : ArrayAdapter<Event?>(context, 0, events!!) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        val event = getItem(position)
        if (view == null) view = LayoutInflater.from(context).inflate(R.layout.event_cell, parent, false)
        val eventCellTV = view!!.findViewById<TextView>(R.id.eventCellTV)
        val eventTitle = event!!.title + " " + event.time
        eventCellTV.text = eventTitle
        val deleteButton = view!!.findViewById<Button>(R.id.eventCellButton)

        val onClickListener = View.OnClickListener {
            Event.eventsList.remove(event)
        }

        deleteButton.setOnClickListener(onClickListener)

        return view
    }

}
