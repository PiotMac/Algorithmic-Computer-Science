package com.example.calendarapp

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.TimePickerDialog.OnTimeSetListener
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import com.example.calendarapp.Formatting.formattedDate
import java.time.LocalTime
import java.util.*


class EventEditActivity : AppCompatActivity() {
    private lateinit var eventNameET: EditText
    private lateinit var eventDateTV: TextView
    private lateinit var eventTimeTV: TextView
    private lateinit var time: LocalTime
    private var timeString: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_edit)
        initWidgets()
        time = LocalTime.now()
        timeString = String.format(Locale.getDefault(), "%02d:%02d", time.hour, time.minute)
        eventDateTV.text = "Date: " + formattedDate(Formatting.selectedDate)
        eventTimeTV.text = "Time: " + timeString
    }

    private fun initWidgets() {
        eventNameET = findViewById(R.id.eventNameET)
        eventDateTV = findViewById(R.id.eventDateTV)
        eventTimeTV = findViewById(R.id.eventTimeTV)
    }

    fun saveEventAction(view: View?) {
        val eventName = eventNameET.text.toString()
        val newEvent = Event(
            eventName,
            Formatting.selectedDate, timeString
        )
        Event.eventsList.add(newEvent)
        time = LocalTime.now()
        finish()
    }

    fun cancelEventAction(view: View?) {
        finish()
    }

    fun setTime(view: View?) {
        var hour = 0
        var minute = 0
        val onTimeSetListener =
            TimePickerDialog.OnTimeSetListener { timePicker, selectedHour, selectedMinute ->
                hour = selectedHour
                minute = selectedMinute

                eventTimeTV.text = "Time: " + String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
                timeString = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
                //Log.i("time", received)
            }
        val timePickerDialog = TimePickerDialog(this, AlertDialog.THEME_HOLO_DARK, onTimeSetListener, hour, minute, true)

        timePickerDialog.setTitle("Select Time")
        timePickerDialog.show()
    }
}