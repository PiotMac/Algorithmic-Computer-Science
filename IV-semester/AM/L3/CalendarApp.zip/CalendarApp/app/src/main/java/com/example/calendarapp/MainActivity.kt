package com.example.calendarapp


import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.example.calendarapp.Formatting.daysInMonthArray
import com.example.calendarapp.Formatting.monthYearFromDate
import java.time.LocalDate


class MainActivity : AppCompatActivity(), CalendarAdapter.OnItemListener {
    private var monthYearText: TextView? = null
    private var calendarRecyclerView: RecyclerView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initWidgets()
        Formatting.selectedDate = LocalDate.now()
        Formatting.originalDate = Formatting.selectedDate
        setMonthView()
    }

    private fun initWidgets() {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView)
        monthYearText = findViewById(R.id.monthYearTV)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("year", Formatting.selectedDate.year)
        outState.putInt("month", Formatting.selectedDate.monthValue)
        outState.putInt("day", Formatting.selectedDate.dayOfMonth)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val year = savedInstanceState.getInt("year")
        val month = savedInstanceState.getInt("month")
        val day = savedInstanceState.getInt("day")
        Formatting.selectedDate = LocalDate.of(year, month, day)
        setMonthView()
    }

    private fun setMonthView() {
        monthYearText?.text = "" + Formatting.selectedDate.month + " " + Formatting.selectedDate.year//monthYearFromDate(Formatting.selectedDate)
        val daysInMonth: ArrayList<LocalDate?> =
            daysInMonthArray(Formatting.selectedDate)
        val calendarAdapter = CalendarAdapter(daysInMonth, this)
        val layoutManager: RecyclerView.LayoutManager = GridLayoutManager(applicationContext, 7)
        calendarRecyclerView!!.layoutManager = layoutManager
        calendarRecyclerView!!.adapter = calendarAdapter
    }

    fun previousMonthAction(view: View?) {
        Formatting.selectedDate =
            Formatting.selectedDate.minusMonths(1)
        setMonthView()
    }

    fun nextMonthAction(view: View?) {
        Formatting.selectedDate =
            Formatting.selectedDate.plusMonths(1)
        setMonthView()
    }

    override fun onItemClick(position: Int, date: LocalDate?) {
        if (date != null) {
            Formatting.selectedDate = date
            setMonthView()
        }
    }

    fun weeklyAction(view: View?) {
        startActivity(Intent(this, WeekViewActivity::class.java))
    }
}







