package com.example.calendarapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.calendarapp.CalendarAdapter.OnItemListener
import com.example.calendarapp.Formatting.daysInWeekArray
import com.example.calendarapp.Formatting.monthYearFromDate
import java.time.LocalDate

class WeekViewActivity : AppCompatActivity(), OnItemListener {
    private lateinit var monthYearText: TextView
    private lateinit var calendarRecyclerView: RecyclerView
    lateinit var eventListView: ListView

    /*
    companion object {
        lateinit var eventListView: ListView
    }

     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_week_view)
        initWidgets()
        setWeekView()
    }

    private fun initWidgets() {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView)
        monthYearText = findViewById(R.id.monthYearTV)
        eventListView = findViewById(R.id.eventListView)
    }

    private fun setWeekView() {
        monthYearText.text = "" + Formatting.selectedDate.month + " " + Formatting.selectedDate.year//monthYearFromDate(Formatting.selectedDate)
        val days: ArrayList<LocalDate?> = daysInWeekArray(Formatting.selectedDate)
        val calendarAdapter = CalendarAdapter(days, this)
        val layoutManager: RecyclerView.LayoutManager = GridLayoutManager(applicationContext, 7)
        calendarRecyclerView.layoutManager = layoutManager
        calendarRecyclerView.adapter = calendarAdapter
        setEventAdapter()
    }

    fun previousWeek(view: View?) {
        Formatting.selectedDate = Formatting.selectedDate.minusWeeks(1)
        setWeekView()
    }

    fun nextWeek(view: View?) {
        Formatting.selectedDate = Formatting.selectedDate.plusWeeks(1)
        setWeekView()
    }

    override fun onItemClick(position: Int, date: LocalDate?) {
        if (date != null) {
            Formatting.selectedDate = date
        }
        setWeekView()
    }

    override fun onResume() {
        super.onResume()
        setEventAdapter()
    }

    private fun setEventAdapter() {
        val dailyEvents: ArrayList<Event> = Event.eventsForDate(
            Formatting.selectedDate
        )
        val eventAdapter = EventAdapter(applicationContext, dailyEvents)
        eventListView.adapter = eventAdapter
    }

    fun newEventAction(view: View?) {
        startActivity(Intent(this, EventEditActivity::class.java))
    }

    fun cancelEventAction(view: View?) {
        finish()
    }
}